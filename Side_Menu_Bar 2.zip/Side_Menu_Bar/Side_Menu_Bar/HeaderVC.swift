//
//  HeaderVC.swift
//  Side_Menu_Bar
//
//  Created by Hence4th on 03/02/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit
import ENSwiftSideMenu
class HeaderVC: UIViewController,ENSideMenuDelegate, UIGestureRecognizerDelegate {
  var click = true
     let myNewView=UIView(frame: CGRect(x: 0, y: 48, width: 415, height: 695))
    override func viewDidLoad() {
        super.viewDidLoad()
        self.sideMenuController()?.sideMenu?.delegate = self
        self.sideMenuController()?.sideMenu?.allowLeftSwipe = true
        self.sideMenuController()?.sideMenu?.allowPanGesture = true
        self.sideMenuController()?.sideMenu?.allowRightSwipe = true
        myNewView.isHidden = true
         myNewView.backgroundColor = UIColor(white: 0, alpha: 0.5)
       
     
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        tap.delegate = self
        self.myNewView.addGestureRecognizer(tap)
        self.view.addSubview(myNewView)
    }
    
    func handleTap(_ sender: UITapGestureRecognizer) {
        // handling code
      //  myNewView.backgroundColor = UIColor(white: 0, alpha: 0.7)
        toggleSideMenuView()
        
    }
    @IBAction func btnaction(_ sender: Any) {
        toggleSideMenuView()
    }

    

    func sideMenuWillOpen(){
        
        myNewView.isHidden = false
    }
    
    func sideMenuWillClose(){
        myNewView.isHidden = true
    }
    
    func sideMenuShouldOpenSideMenu() -> Bool{
        return true
    }
    
    func sideMenuDidOpen(){}
    
    func sideMenuDidClose(){}
    }

