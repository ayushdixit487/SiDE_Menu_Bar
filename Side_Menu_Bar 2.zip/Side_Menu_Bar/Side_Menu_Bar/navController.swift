//
//  navController.swift
//  Alritey
//
//  Created by MACBOOK on 19/12/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit
import ENSwiftSideMenu

class navController: ENSideMenuNavigationController {

    var sideMenuNew : SideMenuVC!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        view.bringSubview(toFront: navigationBar)
        
        // Do any additional setup after loading the view.
    }
        
    func reloadMenuView(_ homeView:ViewController){
        sideMenuNew = self.storyboard?.instantiateViewController(withIdentifier: "SideMenuVC") as! SideMenuVC
        //        sideMenuNew.chkValues()
        navigationController?.isNavigationBarHidden = true
        sideMenu = ENSideMenu(sourceView: self.view, menuViewController: sideMenuNew, menuPosition:.left)
        //        sideMenuNew.homeVC = homeView
        //        sideMenu?.delegate = self //optional
        sideMenu?.menuWidth = 4*UIScreen.main.bounds.width/5 // optional, default is 160
        sideMenu?.bouncingEnabled = false
        
        view.bringSubview(toFront: navigationBar)
    }
}
